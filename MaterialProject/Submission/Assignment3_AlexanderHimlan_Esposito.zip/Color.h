#include <d3dx9math.h>
typedef D3DXCOLOR Color;
