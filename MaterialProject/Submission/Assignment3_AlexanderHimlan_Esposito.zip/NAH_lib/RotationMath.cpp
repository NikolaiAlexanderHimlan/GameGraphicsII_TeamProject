/*
Author: Nikolai Alexander-Himlan
Class: EPG-425 <Section 51>
Assignment: pa 0
Certification of Authenticity:
I certify that this assignment is entirely my own work.
*/
#include "RotationMath.h"

#define _USE_MATH_DEFINES // for C++
#include <math.h>

const float nah::TO_RADIAN = (float)(M_PI / 180);
const float nah::TO_DEGREE = (float)(180 / M_PI);
